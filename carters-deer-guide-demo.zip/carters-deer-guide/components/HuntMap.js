import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet'
import 'leaflet/dist/leaflet.css'
import L from 'leaflet'
import { useEffect } from 'react'

// Fix default icon paths in Leaflet for Next.js
const icon = new L.Icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  tooltipAnchor: [16, -28],
  shadowSize: [41, 41]
})

export default function HuntMap({ center = [35.9557, -80.0053], pins = [] }) {
  useEffect(() => {
    // Ensure map invalidates size when mounted in responsive container
    setTimeout(() => window.dispatchEvent(new Event('resize')), 100)
  }, [])

  return (
    <MapContainer center={center} zoom={12} style={{ width: '100%', height: '100%' }}>
      {/* OpenTopoMap */}
      <TileLayer
        url="https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png"
        attribution='Map data © OpenStreetMap contributors, SRTM | Map style © OpenTopoMap (CC-BY-SA)'
      />
      {pins.map((p, i) => (
        <Marker key={i} position={[p.lat, p.lon]} icon={icon}>
          <Popup>{p.note}</Popup>
        </Marker>
      ))}
    </MapContainer>
  )
}